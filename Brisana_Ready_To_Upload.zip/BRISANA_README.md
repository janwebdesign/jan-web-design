# BRISANA — wdrożenie i ostatnie ustawienia

W paczce znajdują się: `index.html` (kompletna strona z Aurel i Forma) i `brisana-share.jpg` (podgląd przy udostępnianiu linku).

## Publikacja na obecnym GitHub Pages
1. Prześlij **oba pliki** do głównego katalogu repozytorium publikującego `janwebdesign.github.io`, zastępując stary `index.html`.
2. Sprawdź stronę na komputerze i telefonie. Zwróć uwagę na języki PL/EN/DE/UK i formularz kontaktowy.
3. Podgląd przy udostępnieniu może być opóźniony przez pamięć podręczną serwisów.

## Wymaga decyzji właściciela przed przyjmowaniem zapytań
- Wybierz i kup docelową domenę Brisany. Potem zmień na nią canonical URL, `og:url`, `og:image`, `twitter:image` i WebSite URL w `index.html` oraz ustaw DNS GitHub Pages.
- Wybierz firmowy e-mail. Obecnie formularz FormSubmit i wszystkie odnośniki nadal wskazują na istniejącą skrzynkę `jan.webdesign.contact@gmail.com`. Nie została utworzona nowa skrzynka ani adres.
- Aktywuj docelowy adres odbiorczy FormSubmit, potwierdzając e-mail od dostawcy; przetestuj wysyłkę rzeczywistym, nieszkodliwym zgłoszeniem kontrolnym ze swojej przeglądarki. Nie wysłano żadnego testowego zapytania w procesie tworzenia pliku.
- Uzupełnij właściwą informację o prywatności: dane rzeczywistego administratora i kontakt, podstawę prawną, okres przechowywania, prawa osób, transfery i informacje o dostawcach. Tekst aktualnie ostrzega, że nie jest kompletny; nie jest to gotowa polityka prywatności ani porada prawna.
- Zweryfikuj tożsamość firmy, warunki współpracy i rozliczeń, ewentualnie konsultując lokalne wymogi prawne.
- Nie dodawaj fikcyjnych opinii, ocen ani zrealizowanych klientów. Aurel i Forma są oznaczone jako demonstracje.

## Co wykonano
- Spójne brzmienie komunikatów studia (PL/EN/DE/UK), uspójniony opis portfolio i zakładki funkcji demonstracji.
- Doprecyzowany kontakt, zachowane działające wcześniej fallbacki mailowe i honeypot. CAPTCHA ustawiona na wariant HTML POST, natomiast skuteczność antyspamu w AJAX wymaga produkcyjnej weryfikacji.
- Metadane dla social media i branded JPG 1200×630.
- Drobne korekty CSS, czytelność i responsywność. Bez zmian w logice demonstracji hotelu i przemysłu.
